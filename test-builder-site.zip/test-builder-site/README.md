# SPS Test File Builder (online)

One static page (`public/index.html`). It turns the exam exports (compiled result,
question-wise analysis, question mapping, optional question paper) into the test
`.json` file for the results portal.

Student files are read inside the browser and are never uploaded. The server only
serves this page. The page loads two libraries from cdnjs.cloudflare.com
(pdf.js 3.11.174 and SheetJS 0.18.5), so the computer using it needs internet.

## Host it on Firebase Hosting (about 5 minutes)

You need Node.js installed (you already have it for the portal).

1. Open PowerShell in this folder.
2. `npm install -g firebase-tools` (skip if already installed), then `firebase login`.
3. Copy `.firebaserc.example` to `.firebaserc` and put your Firebase project id in it.
   (Using the same project as the results portal is fine, see "Second site" below.)
4. `firebase deploy --only hosting`
5. Open the address it prints (`https://YOUR-PROJECT.web.app`).

To update the page later: replace `public/index.html`, run step 4 again.

### Second site (recommended if the portal already uses Hosting)
Hosting one project's default site would replace the results portal. Create a
separate site instead:

1. `firebase hosting:sites:create sps-test-builder` (choose any free name)
2. In `firebase.json` change `"hosting": {` to
   `"hosting": { "site": "sps-test-builder",`
3. `firebase deploy --only hosting`

The builder is then at `https://sps-test-builder.web.app`.

## Who can open it
The page contains no student data and no secrets, so anyone with the link can open
it, but it is of no use without the exam files. It is marked noindex so search
engines skip it. If you want only teachers to reach it, put it behind
Firebase/Google sign-in or a school-only link; ask for that as a next step.

## Other hosts
Any static host works (Netlify, Cloudflare Pages, GitHub Pages): publish the
`public` folder as is. No build step.
